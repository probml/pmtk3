{\rtf1\mac\ansicpg10000\cocoartf102
{\fonttbl\f0\fswiss\fcharset77 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww10860\viewh14500\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\ql\qnatural

\f0\fs24 \cf0 Reading the optimtips.m file can be done in several ways. First, either\
CD to this directory, or put the directory on your Matlab search path.\
\
Edit the function optimtips.m in the matlab editor. You can now use the\
publish function from the editor toolbar. This will take a minute or so to\
build.\
\
or ...\
\
In the matlab editor, activate cell mode. You can then cause blocks of\
code to be executed in the matlab command window.\
\
or ...\
\
From the matlab command window, use the publish function to create\
a version of this document in your favorite format.\
\
Note: I have observed occasional memory problems due to the length\
of this published document. When this happens I get Java memory errors,\
they seem to occur if I publish this document twice in the same session.\
If this happens to you, then I've included a version that has been broken\
into pieces for your convenience: optimtips_0_20.m, and optimtips_21_36.m.\
\
}